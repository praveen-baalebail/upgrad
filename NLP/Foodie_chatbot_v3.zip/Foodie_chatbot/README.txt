Following software versions are required for building this chatbot

python = 3.7
rasa = 2.0.0a2
tensorflow = 2.31
rasa[spacy] = 2.0.0a2

