## intent:restaurant_search
- find [chinese](cuisine) restaurants in [Bangalore](location) for [high](price) price range
- find [chinese](cuisine) restaurants in [Denver](location) in [high](price) price range
- find restaurants in [bangalore](location) for [chinese](cuisine) cusine in [high](price) price range
- find restaurants in [bangalore](location) for [chinese](cuisine) cuisine with [high](price) price range
- find restaurants in [bangalore](location)
- [Bangalore](location)
- [Italian](cuisine)
- find restaurants in [Delhi](location) for [chinese](cuisine)
- find restaurants in [delhi](location) for [high](price) price
- [American](cuisine)
- find [american](cuisine) restaurants in [delhi](location) for [high](price) price
- [urspraveenb@gmail.com](email)
- I am hungry, looking for some restaurants
- [bangalore](location)
- show me [chinese](cuisine) restaurant
- [jayanagar](location)
- [Delhi](location)
- [urspraveenb@gmail.com](email)
- find me restaurant
- [Hubli](location)
- [South Indian](cuisine)
- [medium](price)
- looking for [North Indian](cuisine) restaurants in [Bangalore](location)
- find me [mid](price) price [south](cuisine) restaurants in [bangalore](location)
- show me [low](price) priced [Italian](cuisine) restaurants in [bangalore](location)
- find [low](price) price [italian](cuisine) restaurants in [bangalore](location)
- find restaurants in [bangalore](location) with [low](price) price [Mexican](cuisine) cuisine

## intent:greet
- high
- hi
- [high](price)

## intent:affirm
- yes

## intent:deny
- no
